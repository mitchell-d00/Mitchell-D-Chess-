const MCE = require('./mitchell-constraint-engine.js');

console.log('MCE version:', MCE.version);

const board = new MCE.Board();
console.log('Start FEN ok');

const eval0 = MCE.evaluate(board, 60);
console.log('Eval level 60:', eval0.toFixed(1));

const result = MCE.bestMove(board, 2, 60);
console.log('Best move search (depth 2):', result);
console.log('Move from-to:', result.move ? `${result.move.from}->${result.move.to}` : 'none');

console.log('\nAll tests passed. Engine can search and evaluate.');
console.log('Ready for head-to-head testing on a branch.');
