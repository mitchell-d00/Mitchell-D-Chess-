# Mitchell Constraint Engine (MCE) v1.1

Self-contained original chess engine for Mitchell D. McPhetridge’s high levels (50–65).

## Features
- Constraint Pressure + Recursive Entropy evaluation
- Admissibility-aware scoring
- Basic move generation (pawns, knights, sliders)
- Alpha-beta search
- No external NNUE or borrowed weights

## Files
- `mitchell-constraint-engine.js`
- `test.js`

## Run test
```bash
node test.js
```

## Usage sketch
```js
const MCE = require('./mitchell-constraint-engine.js');
const board = new MCE.Board();
const { move, score } = MCE.bestMove(board, 3, 65);
```

Designed to live on a branch next to other Mitchell-only candidates.  
Test against Leorik at equal time and only promote if it shows strength.

MIT License.
