# Mitchell Constraint Engine (MCE)

A unique, self-contained chess engine designed specifically for Mitchell D. McPhetridge’s chess game (levels 50–65).

## Design Goals
- **All his**: No external NNUE weights (no Leorik, no Stockfish nets).
- Thematic continuity with his research: constraint pressure, recursive entropy, admissibility gating, closed systems.
- Pure JavaScript, offline-first, single-file compatible.
- Drop-in evaluation that can replace or augment the neural tier.

## Core Unique Features
- **Constraint Pressure (CP)**: Measures pins, king-zone attackers, and recursive constraints on the opponent.
- **Recursive Entropy (RE)**: Approximates the entropy of the opponent’s mobility/attack diversity. Lower entropy is rewarded.
- **Admissibility Gate**: Hard constraint check (inspired by SCOPE). Positions that violate basic constraints are penalized or pruned.
- Classical material + positional backbone remains, so strength is additive.

## Levels 50–65 Mapping
| Level | Features |
|-------|----------|
| 50    | Classical + light CP/RE |
| 51–55 | Full CP/RE + admissibility gate |
| 56–65 | Higher weights + deeper search + stronger constraint pruning |

## Files
- `mitchell-constraint-engine.js` — The engine (Board, evaluation, search skeleton).
- `test.js` — Basic verification suite.
- `README.md` — This file.

## Quick Test
```bash
node test.js
```

## Integration Notes
The `mitchellEvaluate()` function is the main hook. It can be called from the existing `Searcher` / evaluation path in the single HTML chess game. The Board class is a lightweight starting point; the evaluation terms are designed to work with any board representation that exposes piece locations.

This engine is original, inspectable, and philosophically aligned with Mitchell’s constraint-first research program.

MIT License — free to use, modify, and embed.
