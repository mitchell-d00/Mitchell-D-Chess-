/**
 * Mitchell Constraint Engine (MCE)
 * A unique, self-contained chess engine designed for Mitchell D. McPhetridge.
 *
 * Philosophy: Constraint pressure, recursive entropy, and admissibility gating.
 * No external NNUE weights. Pure JavaScript. Offline-first.
 *
 * This is a drop-in style engine focused on levels 50–65 of his chess game.
 * It can be integrated into the single-HTML chess app or used standalone.
 *
 * Author: Designed for mitchell-d00 / Games Inc.
 * License: MIT (same spirit as the original game)
 */

const MCE = (() => {
  // --- Piece constants ---
  const EMPTY = 0;
  const WP = 1, WN = 2, WB = 3, WR = 4, WQ = 5, WK = 6;
  const BP = 7, BN = 8, BB = 9, BR = 10, BQ = 11, BK = 12;
  const PIECE_NAMES = ['', 'P', 'N', 'B', 'R', 'Q', 'K', 'p', 'n', 'b', 'r', 'q', 'k'];

  // --- Board representation (0-63, a1=0) ---
  function sq(file, rank) { return rank * 8 + file; }
  function fileOf(sq) { return sq & 7; }
  function rankOf(sq) { return sq >> 3; }

  // Simple mailbox board for clarity (can be upgraded to bitboards later)
  class Board {
    constructor(fen = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1') {
      this.board = new Array(64).fill(EMPTY);
      this.side = 0; // 0 white, 1 black
      this.castling = 15;
      this.ep = -1;
      this.halfmove = 0;
      this.fullmove = 1;
      this.parseFEN(fen);
    }

    parseFEN(fen) {
      const parts = fen.split(' ');
      const rows = parts[0].split('/');
      let sq = 56;
      for (const row of rows) {
        for (const c of row) {
          if (c >= '1' && c <= '8') sq += +c;
          else {
            const map = {P:WP,N:WN,B:WB,R:WR,Q:WQ,K:WK,p:BP,n:BN,b:BB,r:BR,q:BQ,k:BK};
            this.board[sq++] = map[c] || EMPTY;
          }
        }
        sq -= 16;
      }
      this.side = parts[1] === 'w' ? 0 : 1;
      // castling, ep simplified for this version
    }

    toFEN() {
      // minimal FEN for testing
      let fen = '';
      for (let r = 7; r >= 0; r--) {
        let empty = 0;
        for (let f = 0; f < 8; f++) {
          const p = this.board[sq(f, r)];
          if (p === EMPTY) empty++;
          else {
            if (empty) { fen += empty; empty = 0; }
            fen += PIECE_NAMES[p];
          }
        }
        if (empty) fen += empty;
        if (r > 0) fen += '/';
      }
      return fen + (this.side ? ' b' : ' w') + ' - - 0 1';
    }
  }

  // --- Unique Evaluation: Constraint Pressure + Recursive Entropy ---
  function constraintPressure(board, side) {
    // Count pins, discoveries, king-zone pressure (simplified but unique)
    let score = 0;
    const opp = 1 - side;
    // King location
    let kingSq = -1;
    for (let i = 0; i < 64; i++) {
      if (board[i] === (side === 0 ? WK : BK)) kingSq = i;
    }
    if (kingSq < 0) return 0;

    // King zone pressure (files/ranks around king)
    const kf = fileOf(kingSq), kr = rankOf(kingSq);
    for (let df = -1; df <= 1; df++) {
      for (let dr = -1; dr <= 1; dr++) {
        const f = kf + df, r = kr + dr;
        if (f >= 0 && f < 8 && r >= 0 && r < 8) {
          const s = sq(f, r);
          if (board[s] !== EMPTY && ((board[s] <= 6) !== (side === 0))) {
            score += 20; // attacker in king zone
          }
        }
      }
    }

    // Simple pin detection (ray through king)
    // (Full implementation would walk rays; this is a starter unique term)
    score += Math.random() * 5; // placeholder for full pin scan

    return score * (side === 0 ? 1 : -1);
  }

  function recursiveEntropy(board, side) {
    // Approximate entropy of opponent's mobility / attack diversity
    let attacks = 0;
    const opp = 1 - side;
    for (let i = 0; i < 64; i++) {
      const p = board[i];
      if (p !== EMPTY && ((p <= 6) === (opp === 0))) {
        // crude mobility proxy
        attacks += (p === WN || p === BN) ? 3 : (p === WB || p === BB) ? 5 : 4;
      }
    }
    // Lower entropy is better for the constrainer (higher score for us)
    const entropy = Math.log2(attacks + 1);
    return (side === 0 ? 1 : -1) * (8 - entropy) * 3;
  }

  function admissible(board) {
    // Hard constraint gate: no obvious hanging major pieces without compensation
    // Simplified: count material balance roughly
    let mat = 0;
    for (const p of board) {
      if (p === WQ) mat += 9; else if (p === BQ) mat -= 9;
      if (p === WR) mat += 5; else if (p === BR) mat -= 5;
    }
    return Math.abs(mat) < 12; // allow some imbalance
  }

  function mitchellEvaluate(board, side, level) {
    let score = 0;
    // Classical material
    const values = {1:100,2:320,3:330,4:500,5:900,6:0,7:-100,8:-320,9:-330,10:-500,11:-900,12:0};
    for (const p of board) score += values[p] || 0;

    if (level >= 50) {
      const cp = constraintPressure(board, side);
      const re = recursiveEntropy(board, side);
      const w = Math.min(1.5, 0.4 + (level - 50) * 0.07);
      score += w * (cp + re);

      if (level >= 55 && !admissible(board)) {
        score -= 80 * (side === 0 ? 1 : -1);
      }
    }
    return side === 0 ? score : -score;
  }

  // --- Minimal search (alpha-beta skeleton for testing) ---
  function search(board, depth, alpha, beta, side, level) {
    if (depth === 0) return mitchellEvaluate(board.board, side, level);

    // Generate a few dummy moves for testing (real version needs full movegen)
    // For this test engine we return a static score with depth bonus
    const evalScore = mitchellEvaluate(board.board, side, level);
    return evalScore + depth * 2;
  }

  // Public API
  return {
    Board,
    mitchellEvaluate,
    search,
    constraintPressure,
    recursiveEntropy,
    version: 'MCE-1.0-Mitchell-Constraint-Engine'
  };
})();

// Export for Node or browser
if (typeof module !== 'undefined') module.exports = MCE;
if (typeof window !== 'undefined') window.MCE = MCE;
